﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UFT_Extent_Reports;

namespace UFTMain
{
    class Program
    {
        static void Main(string[] args)
        {
            UFT_Extent_Reports.HTMLReporter myReport = new UFT_Extent_Reports.HTMLReporter();
            myReport.InitializeReport(@"C:\temp\Extent.html");
            myReport.AddReportName("TEST AUTOMATION REPORT");
            myReport.AddDocumentTitle("Business Acceptance Report");
            myReport.CreateTest("FirstTest");
            myReport.AssignAuthorToTest("Skptricks");
            myReport.AssignCategoryToTest("Regression");


            //''' Add Logs to the test
            myReport.AddInfoLog("Test Started");
            myReport.AddErrorLog("Test Error");
        myReport.AddFailLog("Test Failed", @"C:\temp\image1.png");
            myReport.AddFailLog("Test Failed - With Long error", @"C:\temp\image2.png");


            //''''Create another test
            myReport.CreateTest("Second Test");
            myReport.AssignAuthorToTest("Skptricks");
            myReport.AssignCategoryToTest("Functional");


            // ''' Add Logs to the test
            myReport.AddInfoLog("Test Step1");
            myReport.AddInfoLog("Test Step 2");
            myReport.AddPassLog("Test Step Passed", @"C:\temp\image3.png");
            myReport.AddFatalLog("Test Step Passed", @"C:\temp\image4.png");


            //'''Change Theme to dark
            myReport.ChangeToDarkTheme();
            myReport.GenerateReport();

        }
    }
}
